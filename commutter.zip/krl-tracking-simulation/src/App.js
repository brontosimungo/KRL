
import { useEffect, useState } from "react";
import { MapContainer, TileLayer, Polyline, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

const trainIcon = new L.Icon({
  iconUrl: "https://cdn-icons-png.flaticon.com/512/34/34627.png",
  iconSize: [32, 32],
  iconAnchor: [16, 32],
});

const stations = [
  { name: "Tanah Abang", lat: -6.1969, lng: 106.8121 },
  { name: "Palmerah", lat: -6.2081, lng: 106.7986 },
  { name: "Kebayoran", lat: -6.2382, lng: 106.7823 },
  { name: "Pondok Ranji", lat: -6.2802, lng: 106.7411 },
  { name: "Jurangmangu", lat: -6.2857, lng: 106.7295 },
  { name: "Sudimara", lat: -6.2955, lng: 106.7176 },
  { name: "Rawa Buntu", lat: -6.3049, lng: 106.6885 },
  { name: "Serpong", lat: -6.3094, lng: 106.6625 },
  { name: "Cisauk", lat: -6.3204, lng: 106.6299 },
  { name: "Cicayur", lat: -6.3367, lng: 106.6081 },
  { name: "Parung Panjang", lat: -6.3666, lng: 106.5769 },
  { name: "Cilejit", lat: -6.3881, lng: 106.5446 },
  { name: "Daru", lat: -6.4046, lng: 106.5151 },
  { name: "Tenjo", lat: -6.4172, lng: 106.4948 },
  { name: "Tigaraksa", lat: -6.4406, lng: 106.4756 },
  { name: "Cikoya", lat: -6.4546, lng: 106.4548 },
  { name: "Maja", lat: -6.4714, lng: 106.4287 },
  { name: "Citeras", lat: -6.5007, lng: 106.4035 },
  { name: "Rangkasbitung", lat: -6.5646, lng: 106.2518 },
];

// Simulasi jadwal GAPEKA: kereta setiap 15 menit dari pukul 04.00 sampai 23.00
function generateSchedule(startTime = "04:00", endTime = "23:00", intervalMin = 15) {
  const schedule = [];
  const [startHour, startMin] = startTime.split(":").map(Number);
  const [endHour, endMin] = endTime.split(":").map(Number);

  let current = new Date();
  current.setHours(startHour, startMin, 0, 0);

  const end = new Date();
  end.setHours(endHour, endMin, 0, 0);

  while (current <= end) {
    schedule.push(new Date(current));
    current.setMinutes(current.getMinutes() + intervalMin);
  }
  return schedule;
}

const scheduleUp = generateSchedule();     // Tanah Abang -> Rangkasbitung
const scheduleDown = generateSchedule();   // Rangkasbitung -> Tanah Abang

function App() {
  const [trains, setTrains] = useState([]);

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const trainsRunning = [];

      const speed = 50 * 1000 / 3600; // 50 km/h dalam m/s
      const travelTime = 90 * 60; // 90 menit dalam detik
      const lineLength = stations.length;

      // Kereta arah Tanah Abang -> Rangkasbitung
      scheduleUp.forEach((depTime, index) => {
        const elapsed = (now - depTime) / 1000; // dalam detik
        if (elapsed >= 0 && elapsed <= travelTime) {
          const progress = elapsed / travelTime;
          const posIdx = Math.min(Math.floor(progress * (lineLength - 1)), lineLength - 2);
          const lat = stations[posIdx].lat + (stations[posIdx + 1].lat - stations[posIdx].lat) * (progress * (lineLength - 1) % 1);
          const lng = stations[posIdx].lng + (stations[posIdx + 1].lng - stations[posIdx].lng) * (progress * (lineLength - 1) % 1);
          trainsRunning.push({ id: `TA-${index}`, lat, lng, direction: "up" });
        }
      });

      // Kereta arah Rangkasbitung -> Tanah Abang
      scheduleDown.forEach((depTime, index) => {
        const elapsed = (now - depTime) / 1000;
        if (elapsed >= 0 && elapsed <= travelTime) {
          const progress = elapsed / travelTime;
          const posIdx = Math.min(Math.floor(progress * (lineLength - 1)), lineLength - 2);
          const reversedStations = [...stations].reverse();
          const lat = reversedStations[posIdx].lat + (reversedStations[posIdx + 1].lat - reversedStations[posIdx].lat) * (progress * (lineLength - 1) % 1);
          const lng = reversedStations[posIdx].lng + (reversedStations[posIdx + 1].lng - reversedStations[posIdx].lng) * (progress * (lineLength - 1) % 1);
          trainsRunning.push({ id: `RB-${index}`, lat, lng, direction: "down" });
        }
      });

      setTrains(trainsRunning);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <MapContainer center={[-6.3, 106.7]} zoom={10} style={{ height: "100%" }}>
      <TileLayer
        attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <Polyline positions={stations.map(s => [s.lat, s.lng])} color="green" weight={5} />
      {stations.map((station, idx) => (
        <Marker key={idx} position={[station.lat, station.lng]}>
          <Popup>{station.name}</Popup>
        </Marker>
      ))}
      {trains.map((train) => (
        <Marker key={train.id} position={[train.lat, train.lng]} icon={trainIcon}>
          <Popup>Kereta arah {train.direction === "up" ? "Rangkasbitung" : "Tanah Abang"}</Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}

export default App;
