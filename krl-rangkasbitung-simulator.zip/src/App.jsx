import { MapContainer, TileLayer, Marker, Polyline } from 'react-leaflet';
import { useEffect, useState } from 'react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

const stations = [
  { name: 'Tanah Abang', lat: -6.1944, lng: 106.8126, time: '06:00' },
  { name: 'Palmerah', lat: -6.2088, lng: 106.7976, time: '06:06' },
  { name: 'Kebayoran', lat: -6.2387, lng: 106.7872, time: '06:13' },
  { name: 'Pondok Ranji', lat: -6.2756, lng: 106.7421, time: '06:20' },
  { name: 'Jurangmangu', lat: -6.2815, lng: 106.7357, time: '06:24' },
  { name: 'Sudimara', lat: -6.2923, lng: 106.7213, time: '06:28' },
  { name: 'Rawa Buntu', lat: -6.3042, lng: 106.7001, time: '06:32' },
  { name: 'Serpong', lat: -6.3135, lng: 106.6835, time: '06:36' },
  { name: 'Cisauk', lat: -6.3491, lng: 106.6531, time: '06:41' },
  { name: 'Cicayur', lat: -6.3657, lng: 106.6426, time: '06:45' },
  { name: 'Parung Panjang', lat: -6.3986, lng: 106.5764, time: '06:52' },
  { name: 'Cilejit', lat: -6.4101, lng: 106.5446, time: '06:56' },
  { name: 'Daru', lat: -6.4206, lng: 106.5197, time: '06:59' },
  { name: 'Tenjo', lat: -6.4372, lng: 106.4956, time: '07:02' },
  { name: 'Tigaraksa', lat: -6.4463, lng: 106.4784, time: '07:05' },
  { name: 'Cikoya', lat: -6.4553, lng: 106.4623, time: '07:08' },
  { name: 'Maja', lat: -6.4762, lng: 106.4232, time: '07:12' },
  { name: 'Citeras', lat: -6.4888, lng: 106.3977, time: '07:15' },
  { name: 'Rangkasbitung', lat: -6.5027, lng: 106.3935, time: '07:20' },
];

const reverseStations = [...stations].reverse().map((s, i) => {
  const reverseTime = new Date(0, 0, 0, 8, 0 + i * 3);
  return {
    ...s,
    time: `${reverseTime.getHours().toString().padStart(2, '0')}:${reverseTime
      .getMinutes()
      .toString()
      .padStart(2, '0')}`,
  };
});

const trainIcon = new L.Icon({
  iconUrl: 'https://cdn-icons-png.flaticon.com/512/34/34627.png',
  iconSize: [25, 25],
});

function interpolatePosition(start, end, fraction) {
  const lat = start.lat + (end.lat - start.lat) * fraction;
  const lng = start.lng + (end.lng - start.lng) * fraction;
  return { lat, lng };
}

export default function App() {
  const [position, setPosition] = useState(stations[0]);
  const [positionReturn, setPositionReturn] = useState(reverseStations[0]);

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const hhmm = `${now.getHours().toString().padStart(2, '0')}:${now
        .getMinutes()
        .toString()
        .padStart(2, '0')}`;

      for (let i = 0; i < stations.length - 1; i++) {
        const current = stations[i];
        const next = stations[i + 1];

        if (hhmm >= current.time && hhmm < next.time) {
          const startTime = new Date();
          const [sh, sm] = current.time.split(':').map(Number);
          startTime.setHours(sh, sm, 0);

          const endTime = new Date();
          const [eh, em] = next.time.split(':').map(Number);
          endTime.setHours(eh, em, 0);

          const fraction =
            (now.getTime() - startTime.getTime()) /
            (endTime.getTime() - startTime.getTime());

          setPosition(interpolatePosition(current, next, fraction));
        }
      }

      for (let i = 0; i < reverseStations.length - 1; i++) {
        const current = reverseStations[i];
        const next = reverseStations[i + 1];

        if (hhmm >= current.time && hhmm < next.time) {
          const startTime = new Date();
          const [sh, sm] = current.time.split(':').map(Number);
          startTime.setHours(sh, sm, 0);

          const endTime = new Date();
          const [eh, em] = next.time.split(':').map(Number);
          endTime.setHours(eh, em, 0);

          const fraction =
            (now.getTime() - startTime.getTime()) /
            (endTime.getTime() - startTime.getTime());

          setPositionReturn(interpolatePosition(current, next, fraction));
        }
      }
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  return (
    <MapContainer
      center={[-6.3, 106.7]}
      zoom={10}
      style={{ height: '100vh', width: '100%' }}
    >
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution="&copy; OpenStreetMap contributors"
      />
      <Polyline positions={stations.map((s) => [s.lat, s.lng])} color="blue" />
      {stations.map((s, i) => (
        <Marker key={i} position={[s.lat, s.lng]} />
      ))}
      <Marker position={[position.lat, position.lng]} icon={trainIcon} />
      <Marker position={[positionReturn.lat, positionReturn.lng]} icon={trainIcon} />
    </MapContainer>
  );
}
